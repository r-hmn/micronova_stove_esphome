#!/bin/bash

# Base URL
URL="http://esp32.local/dump"

# Output directory (optional)
OUTDIR="./dumps"
mkdir -p "$OUTDIR"

# Start counter
i=1

while true; do
    filename=$(printf "%s/dump_%04d.txt" "$OUTDIR" "$i")
    
    echo "Saving to $filename ..."
    
    # Fetch data and save
    curl -s "$URL" -o "$filename"
    
    # Increment counter
    ((i++))
    
    # Optional delay (seconds)
    sleep 15
done
